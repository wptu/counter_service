<?php
/**
 * Main Schedule View - Shows full year schedule table
 */
?>

<div class="stats-grid">
    <div class="stat-card">
        <h3>วันทำการทั้งปี</h3>
        <div class="value"><?= $data['working_days_count'] ?></div>
    </div>
    <div class="stat-card">
        <h3>RS กลุ่ม B</h3>
        <div class="value"><?= $data['rs_group_counts']['B'] ?></div>
    </div>
    <div class="stat-card">
        <h3>RS กลุ่ม A</h3>
        <div class="value"><?= $data['rs_group_counts']['A'] ?></div>
    </div>
    <div class="stat-card">
        <h3>สัดส่วน B:A</h3>
        <div class="value">
            <?php
            $total = $data['rs_group_counts']['B'] + $data['rs_group_counts']['A'];
            if ($total > 0) {
                $ratio = round(($data['rs_group_counts']['B'] / $total) * 100);
                echo $ratio . ':' . (100 - $ratio);
            } else {
                echo '-';
            }
            ?>
        </div>
    </div>
</div>

<h2>ตารางเวรประจำปี <?= YEAR ?></h2>

<table>
    <thead>
        <tr>
            <th>วันที่</th>
            <th>วัน</th>
            <th>ทพ. - A</th>
            <th>ทพ. - B</th>
            <th>รส.</th>
            <th>วันหยุด</th>
            <th>หมายเหตุ/เหตุผล</th>
        </tr>
    </thead>
    <tbody>
        <?php
        $currentMonth = -1;
        foreach ($data['calendar'] as $day):
            // Extract month from date (dd/mm/yyyy)
            $dateParts = explode('/', $day['date']);
            $month = isset($dateParts[1]) ? (int) $dateParts[1] : 0;

            // Determine row class
            $rowClass = '';
            if ($day['is_weekend']) {
                $rowClass = 'weekend';
            } elseif ($day['is_holiday']) {
                $rowClass = 'holiday';
            } elseif ($day['is_working']) {
                $rowClass = 'working';
            }

            // Alternate background by month
            $bgStyle = '';
            if (!$day['is_weekend'] && !$day['is_holiday']) {
                $bgStyle = ($month % 2 === 0) ? 'background: #ffffff;' : 'background: #f3f3f3;';
            }
            ?>
            <tr class="<?= $rowClass ?>" style="<?= $bgStyle ?>">
                <td><?= htmlspecialchars($day['date']) ?></td>
                <td><?= htmlspecialchars($day['day']) ?></td>
                <td><?= htmlspecialchars($day['tp_a']) ?></td>
                <td><?= htmlspecialchars($day['tp_b']) ?></td>
                <td><?= htmlspecialchars($day['rs']) ?></td>
                <td><?= htmlspecialchars($day['holiday']) ?></td>
                <td style="font-size: 0.85rem;"><?= htmlspecialchars($day['remark']) ?></td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>