<?php
/**
 * Conditions View - Scheduling rules and constraints
 */
?>

<h2>เงื่อนไขและข้อกำหนดการจัดเวร</h2>

<div class="conditions-list">
    <h3>1. โครงสร้างบุคลากร (Staff Structure)</h3>
    <ul>
        <li><strong>กลุ่ม A (Group A):</strong> ตามรายชื่อในไฟล์ข้อมูล</li>
        <li><strong>กลุ่ม B (Group B):</strong> ตามรายชื่อในไฟล์ข้อมูล</li>
    </ul>

    <h3>2. วันและเวลาทำการ (Working Days)</h3>
    <ul>
        <li><strong>เดือน ม.ค., ก.พ., ก.ค., ส.ค.:</strong> จัดเวร จันทร์ - ศุกร์ (เต็มสัปดาห์)</li>
        <li><strong>เดือนอื่นๆ:</strong> จัดเวรเฉพาะ จันทร์, อังคาร, พฤหัสบดี (หยุดพุธและศุกร์)</li>
        <li>หยุดวันเสาร์ - อาทิตย์ (Weekends)</li>
        <li>หยุดวันหยุดราชการ (Public Holidays) ตามประกาศ</li>
        <li>ยกเว้น วันทำงานพิเศษ (Special Working Days) ที่ระบุไว้ให้จัดเวรตามปกติ</li>
    </ul>

    <h3>3. เวร TP (ท่าพระจันทร์) / Office 1</h3>
    <ul>
        <li><strong>จำนวน:</strong> 2 คน/วัน</li>
        <li><strong>องค์ประกอบ:</strong> ต้องมีกลุ่ม A 1 คน และ กลุ่ม B 1 คน</li>
    </ul>

    <h4 style="margin-left: 20px; margin-top: 15px;">เงื่อนไขการเลือกกลุ่ม A:</h4>
    <ol style="margin-left: 40px;">
        <li>พยายามกระจายเวรให้ได้ประมาณ <strong>2-3 ครั้ง/เดือน</strong></li>
        <li>ไม่เลือกคนที่เพิ่งเข้าเวร TP ไปในช่วง 2 วันล่าสุด (เว้นระยะ)</li>
        <li>กระจายวันในสัปดาห์ (จันทร์-ศุกร์) ให้สมดุล</li>
        <li>กระจายยอดรวมจำนวนเวรทั้งปีให้เท่ากัน</li>
    </ol>

    <h4 style="margin-left: 20px; margin-top: 15px;">เงื่อนไขการเลือกกลุ่ม B:</h4>
    <ol style="margin-left: 40px;">
        <li><strong>ต้องมีเวรอย่างน้อย 1 ครั้ง/เดือน</strong> (เงื่อนไขบังคับ - สำคัญที่สุด)</li>
        <li>กระจายยอดรวมจำนวนเวรทั้งปีให้เท่ากันทุกคน (ลำดับความสำคัญที่ 2)</li>
        <li>ไม่เลือกคนที่เพิ่งเข้าเวร TP ไปในช่วง 2 วันล่าสุด</li>
        <li>กระจายวันในสัปดาห์ให้สมดุล</li>
    </ol>

    <h3>4. เวร RS (รังสิต) / Office 2</h3>
    <ul>
        <li><strong>จำนวน:</strong> 1 คน/วัน</li>
        <li><strong>องค์ประกอบ:</strong> เลือกจากกลุ่ม A หรือ B ก็ได้</li>
        <li><strong>สัดส่วนเป้าหมาย:</strong> พยายามให้เป็นกลุ่ม B ประมาณ 80% และกลุ่ม A ประมาณ 20%</li>
    </ul>

    <h4 style="margin-left: 20px; margin-top: 15px;">ข้อห้าม (Constraints):</h4>
    <ol style="margin-left: 40px;">
        <li><strong>ห้ามซ้ำกับคนที่เข้าเวร TP ในวันเดียวกัน</strong> (TP วันนี้)</li>
        <li>ห้ามเป็นคนที่เพิ่งทำงานในวันทำการก่อนหน้า (ทำเมื่อวาน)</li>
        <li>ห้ามเป็นคนที่มีเวร TP ในวันทำการถัดไป (TP พรุ่งนี้)</li>
    </ol>

    <h4 style="margin-left: 20px; margin-top: 15px;">การผ่อนปรน (Progressive Fallback):</h4>
    <ul style="margin-left: 40px;">
        <li><strong>Level 1:</strong> หากหาคนไม่ได้ตามเงื่อนไข จะยอมผ่อนปรนข้อห้ามที่ 2 (ยอมให้ทำงานติดกัน) แต่ยังคงห้าม
            TP พรุ่งนี้</li>
        <li><strong>Level 2:</strong> หากยังหาไม่ได้ จะยอมผ่อนปรนทั้งข้อ 2 และ 3 (เหลือเพียงห้ามชน TP วันนี้)</li>
    </ul>

    <h4 style="margin-left: 20px; margin-top: 15px;">เกณฑ์การเลือก:</h4>
    <ol style="margin-left: 40px;">
        <li>เลือกคนที่มีจำนวนเวรรวมน้อยที่สุด (ลำดับความสำคัญสูงสุด)</li>
        <li>กระจายวันในสัปดาห์ให้สมดุล (ส่วนต่างระหว่างวันไม่เกิน 2-4)</li>
        <li>พยายามกระจายเวรในวันเดียวกันให้เท่ากัน</li>
    </ol>

    <h3>5. อัลกอริทึมการเลือก (Selection Algorithm)</h3>
    <ul>
        <li>ใช้ <strong>Stable Min Selection</strong> - เลือกคนแรกเมื่อคะแนนเท่ากัน (deterministic)</li>
        <li>เรียงรหัสพนักงานแบบ <strong>Natural Sort</strong> (เรียงตามตัวเลข)</li>
        <li>คำนวณคะแนนแบบ <strong>Tuple Comparison</strong> (เปรียบเทียบทีละองค์ประกอบ)</li>
        <li>ผลลัพธ์เหมือนกันทุกครั้งที่รันด้วยข้อมูลเดิม (reproducible)</li>
    </ul>

    <h3>6. การบันทึกและติดตาม (Tracking)</h3>
    <ul>
        <li>ติดตามจำนวนเวรรวมของแต่ละคน (Total Shifts)</li>
        <li>ติดตามจำนวนเวร TP และ RS แยกกัน</li>
        <li>ติดตามจำนวนเวรในแต่ละวัน (จันทร์-ศุกร์)</li>
        <li>ติดตามจำนวนเวร TP รายเดือนของกลุ่ม A และ B</li>
        <li>ติดตามสัดส่วนกลุ่ม B:A ในเวร RS</li>
        <li>บันทึกเหตุผลการเลือก RS (สำหรับ audit)</li>
    </ul>
</div>

<div style="margin-top: 30px; padding: 20px; background: #e7f3ff; border-left: 4px solid #4a86e8; border-radius: 4px;">
    <h4 style="color: #4a86e8; margin-bottom: 10px;">💡 หมายเหตุสำคัญ</h4>
    <p style="margin: 5px 0;">ระบบนี้ใช้อัลกอริทึมเดียวกับ Google Apps Script โดยตรง
        รับประกันว่าผลลัพธ์จะเหมือนกันทุกประการ</p>
    <p style="margin: 5px 0;">การจัดเวรคำนึงถึงความเป็นธรรมและการกระจายภาระงานให้เท่าเทียมกัน</p>
</div>